package day3.assignments;

public class MultiplicationTable {

	public static void main(String[] args) {
		
		int n=5;
		
		for(int i=1;i<=10;i++)
		{
			System.out.println(n +"X"+i+"="+ (n*i));
		}

	}

}
