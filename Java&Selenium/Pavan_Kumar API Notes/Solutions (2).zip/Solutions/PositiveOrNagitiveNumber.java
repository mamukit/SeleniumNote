//Write a Java program print a number is positive or negative.�
package day3.assignments;

public class PositiveOrNagitiveNumber {

	public static void main(String[] args) {

		int num = 10; // positive
		// int num=-10; //Negitive

		if (num > 0) 
		{
			System.out.println(" Number is Positive");
		} else 
		{
			System.out.println("Number is Negitive");
		}

	}

}
