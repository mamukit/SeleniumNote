package day3.assignments;

public class GreatestOfThreeNumbers {

	public static void main(String[] args) {
		
		int a=50;
		int b=100;
		int c=20;
		
		if(a>b && a>c)
		{
			System.out.println(" a is greatest");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is largest");
		}
		else
		{
			System.out.println("c is greatest");
		}
		
	}

}
