package day3;

public class EvenOrOddNumber {

	public static void main(String[] args) {
	
		int num=10;
		
		if(num%2 == 0)
		{
			System.out.println("Number is even number");
		}

		else
		{
			System.out.println("Number is odd number");
		}
	}

}
