package day3;

public class LargestofTwoNumbers {

	public static void main(String[] args) {
		
		int a=50;
		
		int b=20;
		
		if(a>b)
		{
			System.out.println("a is largest");
		}

		else
		{
			System.out.println("b is largest");
		}
	}

}
