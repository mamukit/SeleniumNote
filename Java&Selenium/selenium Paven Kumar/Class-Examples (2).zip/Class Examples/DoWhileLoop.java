package day3;

public class DoWhileLoop {

	public static void main(String[] args) {
	
		/*int i=1;
		
		do
		{
			System.out.println(i); //1 2 3...10
			i++;
		}while(i<=10);*/

		int i=20;
		do
		{
			System.out.println(i); //20
			i++;
		}while(i<=10);
		
		
	}

}
