package day3;

public class IfElseCondition {

	public static void main(String[] args) {
		
		int age=20;
		
		if(age>=18)
		{
			System.out.println("Eligible for vote");
		}
		else
		{
			System.out.println("NOT Eligible for vote");
		}
	}

}
