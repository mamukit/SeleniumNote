package day3;

public class WhileLoop {

	public static void main(String[] args) {
		
		int i=1;
		
		//1 to 10 numbers
		/*while(i<=10)
		{
			System.out.println(i); //1 2 3....9 10
			i++;
		}*/
		
		// even numbers between 1-10
		
		/*i=2;
		while(i<=10)
		{
			System.out.println(i); //2 4 6 8 10
			i+=2;       //i=i+2;
		}*/
		
		
		//print 1 to 10 in decending order
		
		i=10;
		
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
		

	}

}
