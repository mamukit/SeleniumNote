package batchTesting;

import org.testng.Assert;
import org.testng.annotations.Test;

public class PaymentReturns {

	@Test
	void paymentReturnbybank()
	{
		System.out.println("payment return by bank test");
		Assert.assertTrue(true);
	}
	
}
