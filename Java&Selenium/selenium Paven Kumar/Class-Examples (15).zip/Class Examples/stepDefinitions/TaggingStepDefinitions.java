package stepDefinitions;

import cucumber.api.java.en.Given;

public class TaggingStepDefinitions {

	@Given("^This is valid login test$")
	public void this_is_valid_login_test() throws Throwable {
	  
	}

	@Given("^this is logout test$")
	public void this_is_logout_test() throws Throwable {
	   
	}

	@Given("^this is search test$")
	public void this_is_search_test() throws Throwable {
	  
	}

	@Given("^This is advanced search test$")
	public void this_is_advanced_search_test() throws Throwable {
	   
	}

	@Given("^This is prepaid recharge test$")
	public void this_is_prepaid_recharge_test() throws Throwable {
	  
	}

	@Given("^This is post paid recharge test$")
	public void this_is_post_paid_recharge_test() throws Throwable {
	   
	}
}
