package datepickers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DatePickerDemo2 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C://Drivers/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.expedia.ca/");
	
		driver.findElement(By.xpath("//input[@id='hotel-checkin-hp-hotel']")).click();
		
		String month="Mar 2019";
		String exp_date="25";
				
			
		while(true)
		{
			String text=driver.findElement(By.xpath("//caption")).getText();
			
			if(text.equals(month))
			{
				break;
			}
			else
			{
				driver.findElement(By.xpath("//div[@class='datepicker-cal']//button[2]")).click();
			}
		}
		
		List <WebElement> allDates=driver.findElements(By.xpath("//div[@class='datepicker-cal']//div[2]//table[1]//tbody[1]//tr//td//button[1]"));
		
		for(WebElement ele:allDates)
		{
			String date_text=ele.getText();
			
			String date[]=date_text.split("\n");
			
			if(date[1].equals(exp_date))
			{
				ele.click();
				break;
			}
			
		}
	
	}
	
}
