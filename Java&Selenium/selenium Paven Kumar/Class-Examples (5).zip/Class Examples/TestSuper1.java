package day7;

public class TestSuper1 {

	public static void main(String[] args) {
		
		Dog d=new Dog();
		//d.displaycolor(); //Black
		
		//d.eating();
		
	}

}
