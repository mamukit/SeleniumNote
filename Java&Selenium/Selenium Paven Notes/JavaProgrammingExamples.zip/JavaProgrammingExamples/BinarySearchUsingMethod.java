package arrays;

import java.util.Arrays;

public class BinarySearchUsingMethod {
	 
	public static void main(String args[])
	  {
		int array[] = {10, 20, 30, 40, 50 }; //Should be in order
	 
	    System.out.println(Arrays.binarySearch(array, 30));
	  }
}

