package javaBasics;

public class SwappingWithoutThirdVariable {
	
	public static void main(String[] args) {

		int x = 5; 
		int y = 10; 
		
		//x = 10, y = 5
		
		//1. with using third var : t
//		int t;
//		t = x; //5
//		x = y; //10
//		y = t; //5
		
		//2. without using third var: using + operator
//		x = x + y; //15
//		y = x - y; //5
//		x = x - y; // 10
		
		//3. without using third var: using * operator
//		 x = x * y; //50
//		 y = x / y;  //5
//		 x = x / y; //10
		  
		
		System.out.println(x);
		System.out.println(y);
}

	}
	