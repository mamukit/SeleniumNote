package strings;

public class StringToIntegerConversion {

	public static void main(String[] args) {
		
		
		// Convert String To Integer Using Integer.parseInt() method
		  	String s = "2015";
	         
	        int i = Integer.parseInt(s);
	         
	        System.out.println(i); 
	        
	    //Convert String To Integer Using Integer.valueOf() method
	            
	        i = Integer.valueOf(s);
	         
	        System.out.println(i); 
	}

}
