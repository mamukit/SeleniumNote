package arraysandstrings;

import java.util.Arrays;

public class SearchUsingMethod {
	 
		public static void main(String args[])
		  {
			int array[] = {10, 20, 30, 40, 50 }; //Should be in order
		 
		    System.out.println(Arrays.binarySearch(array, 10));
		  }
}
