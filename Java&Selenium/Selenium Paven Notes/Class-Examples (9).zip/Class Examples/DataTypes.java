package day2;

public class DataTypes {

	public static void main(String[] args) {
	
		int a=10;
		double d=20.5;
		char c='H';
		boolean b=false;
		
		String s="welcome";
		
		System.out.println(a);
		System.out.println(d);
		System.out.println(c);
		System.out.println(b);
		System.out.println(s);

	}

}
