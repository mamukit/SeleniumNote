//Write a Java program to print 'Hello' on screen and then print your name on a separate line.

package day2.assignments;

public class PrintHello {

	public static void main(String[] args) {

		System.out.print("Hello");
		System.out.println("Pavan");

	}

}
