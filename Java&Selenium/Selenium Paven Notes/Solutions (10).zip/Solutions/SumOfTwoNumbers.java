//Write a Java program to print the sum of two numbers.�
package day2.assignments;

public class SumOfTwoNumbers {

	public static void main(String[] args) {

		int a = 74;
		int b = 36;

		System.out.println(a + b);

	}

}
