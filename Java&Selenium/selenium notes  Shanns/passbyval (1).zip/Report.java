package passbyval;

public class Report {	
	
	String title = "original";	

}