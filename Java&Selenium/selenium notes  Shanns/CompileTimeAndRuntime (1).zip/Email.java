package ctandrt;

public class Email {
	
	void generateAndSend() {
		System.out.println("logic here to generate and send email");
	}
}